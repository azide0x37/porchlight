# Release

## 2.4.0

- Reduced scheduled AI analysis from every 15 minutes to hourly, with the
  existing randomized delay retained to avoid synchronized requests.
- Replaced the volatile full-snapshot cache key with a versioned semantic
  fingerprint of host topology, endpoint state and characteristics, topology
  counts, and deduplicated irregularities. Scan timestamps and run-history
  churn no longer trigger paid model calls.
- Made MQTT setup responses wait until the bridge-restart action is durably
  queued, eliminating a response/action race in the setup API.

## 2.3.2

- Replaced boot-relative recurring timer starts with activation-relative starts,
  preventing timers reloaded long after boot from entering `active (elapsed)`
  with no next trigger.
- Made install and update restart the web service and recurring timers after
  `daemon-reload`, so new code and schedules take effect immediately.
- Added scan-age health checks and explicit `stale_snapshot` AI status so a
  stopped scanner cannot masquerade as current rendered or generated data.
- Made AI cache reuse dependent on the configured model and service tier, and
  made the worker log its status and fail visibly for configuration, snapshot,
  or upstream errors.
- Added minute-by-minute dashboard refresh with a visible refresh-error state,
  and removed forced Wi-Fi rescans from routine setup-status reads.
- Finalized scan ledger rows before rendering so the UI immediately shows a
  completed run rather than a transient running row.

## 2.3.1

- Classified OpenAI HTTP 429 responses as `rate_limited` instead of surfacing
  raw HTTP exceptions in the dashboard.
- Preserved the last successful generated analysis as stale context when a
  transient upstream failure occurs.
- Added a Settings button and exact `/api/setup/openai/analyze` endpoint to
  queue an immediate AI analysis run.

## 2.3.0

- Added opt-in AI-generated environment, protocol, host, and irregularity
  summaries backed by an asynchronous `porchlight-ai-analysis` systemd sidecar.
- Added configurable AI analysis enablement, model id, and service tier settings
  while continuing to mask the stored OpenAI API key.
- Added scan-to-scan irregularity tracking for new or missing hosts, opened or
  closed services, and service metadata changes, with discover-mode refreshes
  preserved as non-closing observations.

## 2.2.0

- Added dashboard Settings support for storing and clearing an OpenAI API key
  through `/api/setup/openai`, with masked setup responses that never echo the
  secret value.
- Installer now creates and preserves `/etc/porchlight/porchlight.openai.env`
  with mode `0600`.

## 2.1.3

- Refresh packaged static dashboard assets into `/var/lib/porchlight/www`
  during install and update, so appliance upgrades immediately serve the new
  HTML/CSS/icon files instead of waiting for the next render timer.

## 2.1.2

- Fixed overview and settings stat cards so the colored status tone is painted
  as a rounded card background instead of a blurred layer that could square off
  or visually escape at the card corners.

## 2.1.1

- Pointed iOS and PWA install metadata at new, dedicated icon filenames so
  devices do not reuse the previously cached `apple-icon.png` or manifest icon
  paths.
- Added a conventional 180px `apple-touch-icon.png` alongside dedicated
  192px/512px PWA icons, all generated as opaque PNGs without alpha.

## 2.1.0

- Fixed installable PWA icons so iOS and browser install surfaces use opaque,
  correctly sized assets without the transparent border intended for the
  dashboard header lamp.
- Kept the header wordmark on one line at medium viewport widths and switched
  to the compact navigation earlier to avoid cramped desktop wrapping.
- Reworded the dashboard's porch-heavy callouts into more direct network and
  LAN posture language.

## 2.0.0

- Added no-SSH appliance onboarding for Raspberry Pi Zero 2 W images with an
  optional first-boot setup access point.
- Added dashboard settings for Home Assistant MQTT broker destination,
  discovery topics, credentials, and test publishing.
- Added constrained JSON setup APIs and file-backed settings writes that mask
  MQTT passwords and preserve unknown config keys.
- Added appliance-mode installer support for NetworkManager, Avahi, setup
  systemd units, and setup completion.

## 1.1.5

- Linked the footer's Muster self-certification statement to the Muster
  framework repository so the certification claim is explainable from the UI.

## 1.1.4

- Added defensive text wrapping for unusually long hostnames in hero headings,
  analysis text, cards, and chip lists so device names cannot force horizontal
  overflow.
- Added the active Porchlight version and GitHub repository link to the footer.

## 1.1.3

- Tightened the animated brand `i` glyph height so the header wordmark does
  not read as a duplicated character at desktop and medium viewport sizes.

## 1.1.2

- Fixed protocol analysis pluralization for one-host and one-service protocol
  detail pages.
- Stabilized featured-host card layout at medium viewport widths so long
  service-chip lists wrap below host identity instead of compressing hostname
  and address text.

## 1.1.1

- Made overview service cards and the environment analysis derive service
  counts from `services.json` when it is present, so the overview cannot show
  zero ports while the protocols view lists indexed services.
- Matched the reference MQTT/RTSP stat separator with the middle dot glyph.

## 1.1.0

- Corrected dashboard display typography to use the reference font weights for
  serif headings, stat values, and the brand mark.
- Made the page body a full-height flex column so sparse routes grow the main
  content area and keep the footer at the bottom of the viewport.

## 1.0.0

- Replaced the minimal generated table dashboard with hosted static assets
  adapted from `azide0x37/porchlight-dashboard`.
- The dashboard now reads the rendered Porchlight JSON sidecars at runtime, so
  the appliance UI updates with each scanner render without needing Node.
- Added dashboard dark mode with system-preference detection, a persistent
  header toggle, and dark-theme CSS tokens.
- Ported the reference dashboard header treatment more faithfully: compact
  icon-only theme controls, header halo/fireflies, hash-route view transitions,
  and a mobile hamburger drawer.
- Vendored the exact deployed Inter, Fraunces, and JetBrains Mono WOFF2 assets
  plus the reference PWA icon set for offline appliance/PWA use.
- Added iOS safe-area metadata, Apple web app metadata, versioned CSS/JS URLs,
  no-store headers for mutable dashboard assets, and mobile 2-column stat tiles.
- Added Muster contract tests that prove the dashboard webroot is packaged and
  backed by `/status.json`, `/hosts.json`, `/services.json`, and
  `/snapshot.json`.

## 0.4.0

- Active scans now run against discovered private hosts instead of blocking on
  broad LAN CIDR size, so a `/22` network can still scan the bounded observed
  host list.
- Added reverse-DNS/PTR name enrichment through `getent hosts`.
- Added service categorization for HTTP, RTSP, MQTT, and common internal ports.
- Added HTTP/HTTPS dashboard links and optional root page title fetching.
- Added Home Assistant sensors for HTTP, RTSP, MQTT, and internal service
  counts.

## 0.3.1

- Fixed scan unit hardening to allow `AF_NETLINK`, which `ip -j
  route/addr/neigh` requires under systemd.

## 0.3.0

- Added the package-backed scanner implementation for config, discovery, Nmap
  XML parsing, SQLite storage, dashboard rendering, health, and web serving.
- Added `porchlight-render`, `porchlight-health`, `porchlight-web`,
  `scan-now.sh`, and `porchlightctl` runtime entrypoints.
- Added systemd timers for discovery, deep scan, render, and health, plus a
  systemd-owned local dashboard service.
- Installer now ships the Python package, scanner/web/health/render entrypoints,
  all systemd units, and apt scanner dependencies (`nmap`, `arp-scan`).
- Doctor now proves SQLite ledger creation, dashboard snapshot rendering, and
  Muster health status output.

## 0.2.0

- Added the first real scanner implementation through `src/porchlight-scan`.
- Added `porchlight-scan.service`, `porchlight-scan.timer`,
  `porchlight-discover.service`, and `porchlight-deep-scan.service`.
- Scanner now writes `/run/porchlight/status.json`, `/run/muster/status.json`,
  and `/var/lib/porchlight/www/*.json` using LAN neighbor and Tailscale data.
- Installer now deploys scanner units and enables the scan timer.

## 0.1.1

- Added apt-based installation for `mosquitto-clients` so real MQTT publishing
  has the configured `mosquitto_pub` adapter available.
- Added a doctor check that fails clearly when `HA_MQTT_ENABLE=1` and the
  configured MQTT publish adapter is missing.

## 0.1.0

- Initial Muster self-certified Porchlight appliance skeleton.
- Added Home Assistant MQTT bridge using mock-first discovery, state, and control artifacts.
- Added versioned install layout under `/opt/porchlight/releases/<version>/`.
- Added `doctor.sh`, `update.sh`, `uninstall.sh`, package generation, and self-certification tests.
